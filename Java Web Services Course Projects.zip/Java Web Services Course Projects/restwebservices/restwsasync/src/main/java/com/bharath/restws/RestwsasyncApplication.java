package com.bharath.restws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestwsasyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestwsasyncApplication.class, args);
	}
}
