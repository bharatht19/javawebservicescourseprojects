package com.bharath.restwsclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestwsclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestwsclientApplication.class, args);
	}
}
