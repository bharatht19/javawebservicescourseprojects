package com.bharath.ws.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtclientApplication.class, args);
	}
}
