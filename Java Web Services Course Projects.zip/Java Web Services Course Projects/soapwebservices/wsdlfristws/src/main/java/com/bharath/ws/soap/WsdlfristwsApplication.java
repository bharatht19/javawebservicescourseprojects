package com.bharath.ws.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsdlfristwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WsdlfristwsApplication.class, args);
	}
}
